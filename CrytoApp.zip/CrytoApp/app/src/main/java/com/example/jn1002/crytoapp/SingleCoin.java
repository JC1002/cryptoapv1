package com.example.jn1002.crytoapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SingleCoin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_coin);

        Bundle basket =getIntent().getExtras();
        String s = basket.getString("image");
    }
}
