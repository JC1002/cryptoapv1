package com.example.jn1002.crytoapp.Interface;

public interface ILoadMore {
    void onLoadMore();

}
